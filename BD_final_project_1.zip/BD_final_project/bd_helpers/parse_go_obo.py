#!/usr/bin/env python
import os


def parse_obo(obo_file):
    graph = {}  # { term_id : term_object }
    obj = {}    # { id: term_id, name: definition, is_a: list_of_parents, is_obsolete: True, namespace: namespace }
    
    with open(obo_file) as f:
        for line in f:
            line = line.strip().split(": ")
            if line and len(line) > 1:
                k, v = line[:2]
                if k == "id" and v.startswith("GO:"):
                    obj["id"] = v
                elif k == "alt_id" and v.startswith("GO:"):
                    obj.setdefault("alt_id", []).append(v)
                elif k == "name":
                    obj["def"] = v
                elif k == "is_a" and v.startswith("GO:"):
                    obj.setdefault("is_a", []).append(v.split()[0])
                elif k == "is_obsolete":
                    obj["is_obsolete"] = True
                elif k == "namespace":
                    obj["namespace"] = v
            else:
                if obj.get("id") and not obj.get("is_obsolete"):
                    if "is_a" not in obj:
                        obj["is_root"] = True
                    graph[obj["id"]] = obj
                obj = {}
    return graph


def get_ancestors(graph):
    roots = set()
    for node in graph:
        if graph[node].get("is_root"):
            roots.add(node)

    depth = {}
    ancestors = {}  # { term : list_of_ancestor_terms }
    
    for node in graph:
        c = 0
        node_ancestors = []
        node_parents = graph[node].get("is_a")

        while node_parents:
            c += 1

            if node not in depth and roots.intersection(set(node_parents)):
                depth[node] = c

            node_ancestors.extend(node_parents)
            node_parents = [term for parent in node_parents for term in graph[parent].get("is_a", [])]

        ancestors[node] = set(node_ancestors)
    return ancestors, depth, roots


def get_children(ancestors):
    children = {}  # { node : list_of_children }, leaf terms are not keys
    for node in ancestors:
        for ancestor in ancestors[node]:
            children.setdefault(ancestor, set()).add(node)
    return children