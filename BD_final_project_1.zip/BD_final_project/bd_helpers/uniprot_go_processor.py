import re

def extract_go_annotations(entry):
    accession_match = re.findall(r"<accession>(.*?)<\/accession>", entry)

    go_matches = re.findall(r'<dbReference type="GO" id="GO:(.*?)">', entry)
    go_annotations = [f"GO:{go}" for go in go_matches]
    if not go_annotations:
        go_annotations = ["NOGO"]

    all_go_ids = ";".join(go_annotations)
    all_data = [f"{a},{all_go_ids}" for a in accession_match]

    text = "\n".join(all_data)

    text = text + "\n"

    return text


file_path = "processed_sprot.txt"

with open(file_path, "r") as file:
    in_entry = False
    entry_lines = []
    for line in file:
        if "<entry dataset" in line:
            if in_entry:
                entry = "".join(entry_lines)
                print(extract_go_annotations(entry), end="")
                entry_lines = []

            in_entry = True
        elif "<entry dataset" not in line:
            entry_lines.append(line)

    # Process the last entry if any
    if entry_lines:
        entry = "".join(entry_lines)
        print(extract_go_annotations(entry))